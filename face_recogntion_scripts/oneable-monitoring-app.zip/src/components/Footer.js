function Footer() {
    return (
      <footer className="footer">
        <p>&copy; 2023 Your Brand. All rights reserved.</p>
      </footer>
    );
  }
  
  export default Footer;
  